import json
import requests
from bs4 import BeautifulSoup

######################################
#### Subaru Parts Pros PN Scraper ####
######################################
def lambda_handler(event, context):
    headers = json.loads(event)['headers']
    proxies = json.loads(event)['proxies']
    part_number = json.loads(event)['part_number']

    # DEBUG PARAMS
    # headers = event['headers']
    # proxies = event['proxies']
    # part_number = event['part_number']

    base_URL = 'https://www.subarupartspros.com'
    query_url = f'{base_URL}/catalogsearch/result/?q={part_number}'
    resp = requests.get(query_url, proxies=proxies, headers=headers)
    soup = BeautifulSoup(resp.content, 'html.parser')
    # print(soup)
    results_array = []
    try:
        container = soup.find('ul', class_='products-grid')
        # print(container)
        listings = container.find_all('li', class_='item')
        # print(listings)
        for listing in listings:
            # print(listing)
            listing_obj = {}
            try:
                product_link = listing.find('a', class_='product-image')
                product_link_full = product_link['href']
                product_name = listing.find('h2', class_='product-name').text.strip()
                product_photo = listing.find('img', class_='defaultImage')['src']
                product_price = listing.find('span', class_='price').text.strip()
            except (AttributeError, TypeError, KeyError):
                continue

            listing_obj['link'] = product_link_full
            listing_obj['name'] = product_name
            listing_obj['image'] = product_photo
            listing_obj['price'] = product_price
            listing_obj['source'] = 'subaru_parts_pros.jpg'

            results_array.append(listing_obj)
    except AttributeError:
        pass
    return json.dumps(results_array)